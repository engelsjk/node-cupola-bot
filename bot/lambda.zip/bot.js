const iss = require('./components/iss.js');
const image = require('./components/image.js');
const tweet = require('./components/tweet.js');
///

const image_settings = {
    filepath_image: '/tmp/image.png',
    filepath_image_satellite: '/tmp/image_satellite.png',
    filepath_mask: 'assets/mask.png',
    zoom: 7.75,
    imagesize: "736x1105",
    mapstyle: 'atthegate/cjexp3fnq3i702sqt3qjnqwta'
}

///

var iss_position = iss.getISSPosition();
var daylight = iss.checkDaylight(iss_position);

image.getSatelliteImage(iss_position, daylight, image_settings);
image.getCupolaImage(image_settings)
tweet.sendTweet(image_settings);





