module.exports = {
  mapbox_token: 'pk.eyJ1IjoiYXR0aGVnYXRlIiwiYSI6ImNqYTM3dTdlaTczd2Uyd3BndDJ1dnhiOW0ifQ.tXu5XKo01fyUvFEIMugOgw',
  mapbox_style_night: 'atthegate/cjexp3fnq3i702sqt3qjnqwta',
  twitter_consumer_key: 'aQCFEA0CmLdGT5mFCyd9hOkqF',  
  twitter_consumer_secret: 'qCCgZR5T2GZjyUCBwpVMSet9dVrbfY4apY4963C7kTbD0NtJG6',
  twitter_access_token: '975625901089042432-v3QX1GxW90GE1j5jPpvJ0ZYLbi7TVxD',  
  twitter_access_token_secret: 'IxhVMx0miGY8Fqu5p0PQMSFBMIrjYLlRQ539hpj7vE2wN'
}